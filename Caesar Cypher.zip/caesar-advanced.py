value=eval(input("Enter a key value:"))
fileName= input("Enter a file name to read:")
fileNameEncode= input("Enter a file name to encode:")
fileNameDecode= input("Enter a file name to decode:")

infile= open(fileName, 'r')
outfile= open (fileNameEncode,'w')
for lines in infile.readlines():
    for letters in lines:
        if 65<=ord(letters)<=122:
         newcode= chr(ord(letters)+value)
         a= (ord(newcode)-65)%58
         b= chr(a+ 65)
         print(b,end ="",file=outfile)
        else:
            print(letters,end="",file=outfile)
infile.close()
outfile.close()
infile2 = open (fileNameEncode, 'r')
outfile2= open (fileNameDecode, 'w')

for lines2 in infile2.readlines():
        for letters2 in lines2:
            if 65<=ord(letters2)<=122:
                newcode2= chr(ord(letters2)-value)

                print(newcode2.replace("?","y"), end="", file=outfile2 )
            else:
                print(letters2, end="", file=outfile2)
infile2.close()
