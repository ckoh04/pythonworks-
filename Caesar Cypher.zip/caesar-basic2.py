value=eval(input("Enter a key value:"))
fileName= input("Enter a file name to read:")
fileNameEncode= input("Enter a file name to encode:")
fileNameDecode= input("Enter a file name to decode:")


infile= open(fileName, 'r')
outfile= open (fileNameEncode,'w')

for lines in infile.readlines():
    for letters in lines:
        newcode=ord(letters)+ value
        print(chr(newcode),end ="",file=outfile)
    print(file=outfile)
infile.close()
outfile.close()
infile2 = open (fileNameEncode, 'r')
outfile2= open (fileNameDecode, 'w')

for lines2 in infile2.readlines():
    for letters2 in lines2:
        newcode2= ord(letters2)-value
        if newcode2=='\n':
            continue
        print ((chr(newcode2)),end="", file=outfile2)
infile2.close()




