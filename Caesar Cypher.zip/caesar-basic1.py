value=eval(input("Enter a key value:"))
fileName= input("Enter a file name to read:")

file= open(fileName, 'r')
count = 0
for lines in file.readlines():
    for letters in lines:
        newcode=ord(letters)+ value
        count= count +1
        print (chr(int(newcode)), end="")
    print()

